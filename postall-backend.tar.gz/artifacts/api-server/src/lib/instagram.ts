import { logger } from "./logger";

const GRAPH_API_BASE = "https://graph.facebook.com/v19.0";

export type MediaType = "IMAGE" | "VIDEO";

export interface MediaItem {
  mediaUrl: string;
  mediaType: MediaType;
}

async function graphPost(
  path: string,
  params: Record<string, string>,
): Promise<{ id: string }> {
  const url = new URL(`${GRAPH_API_BASE}${path}`);
  const body = new URLSearchParams(params);

  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });

  const data = (await res.json()) as { id?: string; error?: { message: string } };

  if (!res.ok || !data.id) {
    const message = data.error?.message ?? `HTTP ${res.status}`;
    logger.error({ path, status: res.status, message }, "Instagram Graph API error");
    throw new Error(message);
  }

  return { id: data.id };
}

export async function publishToInstagram(
  instagramAccountId: string,
  accessToken: string,
  caption: string,
  media: MediaItem[],
): Promise<string> {
  if (media.length === 0) {
    throw new Error("At least one media item is required");
  }

  if (media.length === 1) {
    const item = media[0];
    const isVideo = item.mediaType === "VIDEO";

    const containerParams: Record<string, string> = {
      caption,
      access_token: accessToken,
    };

    if (isVideo) {
      containerParams.media_type = "REELS";
      containerParams.video_url = item.mediaUrl;
    } else {
      containerParams.image_url = item.mediaUrl;
    }

    const container = await graphPost(
      `/${instagramAccountId}/media`,
      containerParams,
    );

    if (isVideo) {
      await waitForContainer(container.id, accessToken);
    }

    const published = await graphPost(`/${instagramAccountId}/media_publish`, {
      creation_id: container.id,
      access_token: accessToken,
    });

    return published.id;
  }

  const itemContainerIds: string[] = [];
  for (const item of media) {
    const isVideo = item.mediaType === "VIDEO";
    const params: Record<string, string> = {
      is_carousel_item: "true",
      access_token: accessToken,
    };
    if (isVideo) {
      params.media_type = "VIDEO";
      params.video_url = item.mediaUrl;
    } else {
      params.image_url = item.mediaUrl;
    }
    const c = await graphPost(`/${instagramAccountId}/media`, params);
    if (isVideo) {
      await waitForContainer(c.id, accessToken);
    }
    itemContainerIds.push(c.id);
  }

  const carousel = await graphPost(`/${instagramAccountId}/media`, {
    media_type: "CAROUSEL",
    caption,
    children: itemContainerIds.join(","),
    access_token: accessToken,
  });

  const published = await graphPost(`/${instagramAccountId}/media_publish`, {
    creation_id: carousel.id,
    access_token: accessToken,
  });

  return published.id;
}

async function waitForContainer(
  containerId: string,
  accessToken: string,
  maxAttempts = 30,
  intervalMs = 3000,
): Promise<void> {
  for (let i = 0; i < maxAttempts; i++) {
    const url = new URL(`${GRAPH_API_BASE}/${containerId}`);
    url.searchParams.set("fields", "status_code");
    url.searchParams.set("access_token", accessToken);

    const res = await fetch(url.toString());
    const data = (await res.json()) as {
      status_code?: string;
      error?: { message: string };
    };

    if (data.status_code === "FINISHED") return;
    if (data.status_code === "ERROR") {
      throw new Error("Instagram media container processing failed");
    }

    await new Promise((r) => setTimeout(r, intervalMs));
  }

  throw new Error("Timed out waiting for Instagram media container");
}
