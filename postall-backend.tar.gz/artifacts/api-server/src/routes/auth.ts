import { Router, type IRouter } from "express";

const GRAPH_API_BASE = "https://graph.facebook.com/v19.0";

const router: IRouter = Router();

router.get("/auth/token-exchange", async (req, res): Promise<void> => {
  const shortLivedToken = req.query["short_lived_token"];

  if (!shortLivedToken || typeof shortLivedToken !== "string") {
    res.status(400).json({ error: "short_lived_token query parameter is required" });
    return;
  }

  const appId = process.env["META_APP_ID"]!;
  const appSecret = process.env["META_APP_SECRET"]!;

  const url = new URL(`${GRAPH_API_BASE}/oauth/access_token`);
  url.searchParams.set("grant_type", "fb_exchange_token");
  url.searchParams.set("client_id", appId);
  url.searchParams.set("client_secret", appSecret);
  url.searchParams.set("fb_exchange_token", shortLivedToken);

  const graphRes = await fetch(url.toString());
  const data = (await graphRes.json()) as {
    access_token?: string;
    token_type?: string;
    expires_in?: number;
    error?: { message: string; type: string; code: number };
  };

  if (!graphRes.ok || !data.access_token) {
    const message = data.error?.message ?? `Graph API error (HTTP ${graphRes.status})`;
    req.log.error({ status: graphRes.status, message }, "Token exchange failed");
    res.status(400).json({ error: message });
    return;
  }

  req.log.info("Token exchange successful");
  res.json({
    accessToken: data.access_token,
    tokenType: data.token_type ?? "bearer",
    expiresIn: data.expires_in ?? null,
  });
});

router.get("/auth/debug-token", async (req, res): Promise<void> => {
  const token = req.query["access_token"];

  if (!token || typeof token !== "string") {
    res.status(400).json({ error: "access_token query parameter is required" });
    return;
  }

  const appId = process.env["META_APP_ID"]!;
  const appSecret = process.env["META_APP_SECRET"]!;
  const appToken = `${appId}|${appSecret}`;

  const url = new URL(`${GRAPH_API_BASE}/debug_token`);
  url.searchParams.set("input_token", token);
  url.searchParams.set("access_token", appToken);

  const graphRes = await fetch(url.toString());
  const data = (await graphRes.json()) as {
    data?: {
      app_id: string;
      is_valid: boolean;
      expires_at?: number;
      scopes?: string[];
      user_id?: string;
    };
    error?: { message: string };
  };

  if (!graphRes.ok || !data.data) {
    const message = data.error?.message ?? `Graph API error (HTTP ${graphRes.status})`;
    req.log.error({ status: graphRes.status, message }, "Token debug failed");
    res.status(400).json({ error: message });
    return;
  }

  const info = data.data;
  res.json({
    isValid: info.is_valid,
    appId: info.app_id,
    userId: info.user_id ?? null,
    expiresAt: info.expires_at ? new Date(info.expires_at * 1000).toISOString() : null,
    scopes: info.scopes ?? [],
  });
});

router.get("/auth/accounts", async (req, res): Promise<void> => {
  const token = req.query["access_token"];

  if (!token || typeof token !== "string") {
    res.status(400).json({ error: "access_token query parameter is required" });
    return;
  }

  const pagesUrl = new URL(`${GRAPH_API_BASE}/me/accounts`);
  pagesUrl.searchParams.set("fields", "id,name,access_token");
  pagesUrl.searchParams.set("access_token", token);

  const pagesRes = await fetch(pagesUrl.toString());
  const pagesData = (await pagesRes.json()) as {
    data?: Array<{ id: string; name: string; access_token: string }>;
    error?: { message: string };
  };

  if (!pagesRes.ok || !pagesData.data) {
    const message = pagesData.error?.message ?? `Graph API error (HTTP ${pagesRes.status})`;
    req.log.error({ status: pagesRes.status, message }, "Failed to fetch Facebook Pages");
    res.status(400).json({ error: message });
    return;
  }

  const pages = pagesData.data;

  if (pages.length === 0) {
    res.json([]);
    return;
  }

  const results = await Promise.all(
    pages.map(async (page) => {
      const igUrl = new URL(`${GRAPH_API_BASE}/${page.id}`);
      igUrl.searchParams.set(
        "fields",
        "instagram_business_account{id,name,username,profile_picture_url}",
      );
      igUrl.searchParams.set("access_token", page.access_token);

      const igRes = await fetch(igUrl.toString());
      const igData = (await igRes.json()) as {
        instagram_business_account?: {
          id: string;
          name?: string;
          username?: string;
          profile_picture_url?: string;
        };
      };

      const ig = igData.instagram_business_account;
      if (!ig) return null;

      return {
        facebookPageId: page.id,
        facebookPageName: page.name,
        pageAccessToken: page.access_token,
        instagramAccountId: ig.id,
        instagramName: ig.name ?? null,
        instagramUsername: ig.username ?? null,
        profilePictureUrl: ig.profile_picture_url ?? null,
      };
    }),
  );

  const igAccounts = results.filter(Boolean);

  req.log.info({ count: igAccounts.length }, "Fetched Instagram Business accounts");
  res.json(igAccounts);
});

router.get("/auth/refresh-token", async (req, res): Promise<void> => {
  const token = req.query["access_token"];

  if (!token || typeof token !== "string") {
    res.status(400).json({ error: "access_token query parameter is required" });
    return;
  }

  const appId = process.env["META_APP_ID"]!;
  const appSecret = process.env["META_APP_SECRET"]!;

  const url = new URL(`${GRAPH_API_BASE}/oauth/access_token`);
  url.searchParams.set("grant_type", "fb_exchange_token");
  url.searchParams.set("client_id", appId);
  url.searchParams.set("client_secret", appSecret);
  url.searchParams.set("fb_exchange_token", token);

  const graphRes = await fetch(url.toString());
  const data = (await graphRes.json()) as {
    access_token?: string;
    token_type?: string;
    expires_in?: number;
    error?: { message: string; type: string; code: number };
  };

  if (!graphRes.ok || !data.access_token) {
    const message = data.error?.message ?? `Graph API error (HTTP ${graphRes.status})`;
    req.log.error({ status: graphRes.status, message }, "Token refresh failed");
    res.status(400).json({ error: message });
    return;
  }

  req.log.info("Token refresh successful");
  res.json({
    accessToken: data.access_token,
    tokenType: data.token_type ?? "bearer",
    expiresIn: data.expires_in ?? null,
  });
});

export default router;
