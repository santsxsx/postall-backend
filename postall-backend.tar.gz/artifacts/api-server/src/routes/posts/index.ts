import { Router, type IRouter } from "express";
import { eq, and, inArray } from "drizzle-orm";
import { db, postsTable, postMediaTable, accountsTable } from "@workspace/db";
import {
  CreatePostBody,
  GetPostParams,
  UpdatePostParams,
  UpdatePostBody,
  DeletePostParams,
  PublishPostParams,
  ListPostsQueryParams,
} from "@workspace/api-zod";
import { publishToInstagram } from "../../lib/instagram";

const router: IRouter = Router();

async function getPostWithMedia(postId: number) {
  const [post] = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.id, postId));

  if (!post) return null;

  const media = await db
    .select()
    .from(postMediaTable)
    .where(eq(postMediaTable.postId, postId))
    .orderBy(postMediaTable.sortOrder);

  return { ...post, media };
}

router.get("/posts", async (req, res): Promise<void> => {
  const query = ListPostsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const conditions = [];
  if (query.data.accountId != null) {
    conditions.push(eq(postsTable.accountId, query.data.accountId));
  }
  if (query.data.status != null) {
    conditions.push(eq(postsTable.status, query.data.status));
  }

  const posts = await db
    .select()
    .from(postsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(postsTable.createdAt);

  if (posts.length === 0) {
    res.json([]);
    return;
  }

  const postIds = posts.map((p) => p.id);
  const allMedia = await db
    .select()
    .from(postMediaTable)
    .where(inArray(postMediaTable.postId, postIds))
    .orderBy(postMediaTable.sortOrder);

  const mediaByPost = new Map<number, typeof allMedia>();
  for (const m of allMedia) {
    const list = mediaByPost.get(m.postId) ?? [];
    list.push(m);
    mediaByPost.set(m.postId, list);
  }

  const result = posts.map((p) => ({
    ...p,
    media: mediaByPost.get(p.id) ?? [],
  }));

  res.json(result);
});

router.post("/posts", async (req, res): Promise<void> => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { media, ...postData } = parsed.data;

  if (!postData.caption) postData.caption = "";
  if (!postData.status) postData.status = "draft";

  const [post] = await db
    .insert(postsTable)
    .values(postData)
    .returning();

  if (media && media.length > 0) {
    await db.insert(postMediaTable).values(
      media.map((m, i) => ({
        postId: post.id,
        mediaUrl: m.mediaUrl,
        mediaType: m.mediaType ?? "IMAGE",
        sortOrder: m.sortOrder ?? i,
      })),
    );
  }

  const full = await getPostWithMedia(post.id);
  res.status(201).json(full);
});

router.get("/posts/:id", async (req, res): Promise<void> => {
  const params = GetPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const post = await getPostWithMedia(params.data.id);
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  res.json(post);
});

router.patch("/posts/:id", async (req, res): Promise<void> => {
  const params = UpdatePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdatePostBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.id, params.data.id));

  if (!existing) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  const { media, ...postUpdates } = parsed.data;

  if (Object.keys(postUpdates).length > 0) {
    await db
      .update(postsTable)
      .set(postUpdates)
      .where(eq(postsTable.id, params.data.id));
  }

  if (media !== undefined) {
    await db.delete(postMediaTable).where(eq(postMediaTable.postId, params.data.id));
    if (media.length > 0) {
      await db.insert(postMediaTable).values(
        media.map((m, i) => ({
          postId: params.data.id,
          mediaUrl: m.mediaUrl,
          mediaType: m.mediaType ?? "IMAGE",
          sortOrder: m.sortOrder ?? i,
        })),
      );
    }
  }

  const full = await getPostWithMedia(params.data.id);
  res.json(full);
});

router.delete("/posts/:id", async (req, res): Promise<void> => {
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(postsTable)
    .where(eq(postsTable.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/posts/:id/publish", async (req, res): Promise<void> => {
  const params = PublishPostParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const post = await getPostWithMedia(params.data.id);
  if (!post) {
    res.status(404).json({ error: "Post not found" });
    return;
  }

  if (post.status === "published") {
    res.status(400).json({ error: "Post is already published" });
    return;
  }

  if (post.media.length === 0) {
    res.status(400).json({ error: "Post must have at least one media item" });
    return;
  }

  const [account] = await db
    .select()
    .from(accountsTable)
    .where(eq(accountsTable.id, post.accountId));

  if (!account) {
    res.status(400).json({ error: "Account not found" });
    return;
  }

  try {
    const instagramPostId = await publishToInstagram(
      account.instagramAccountId,
      account.accessToken,
      post.caption,
      post.media.map((m) => ({
        mediaUrl: m.mediaUrl,
        mediaType: m.mediaType as "IMAGE" | "VIDEO",
      })),
    );

    const [updated] = await db
      .update(postsTable)
      .set({
        status: "published",
        publishedAt: new Date(),
        instagramPostId,
        errorMessage: null,
      })
      .where(eq(postsTable.id, params.data.id))
      .returning();

    const full = await getPostWithMedia(updated.id);
    res.json(full);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";

    await db
      .update(postsTable)
      .set({ status: "failed", errorMessage: message })
      .where(eq(postsTable.id, params.data.id));

    res.status(400).json({ error: `Instagram publish failed: ${message}` });
  }
});

export default router;
