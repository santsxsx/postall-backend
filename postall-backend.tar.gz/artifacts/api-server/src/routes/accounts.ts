import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, accountsTable } from "@workspace/db";
import {
  CreateAccountBody,
  GetAccountParams,
  UpdateAccountParams,
  UpdateAccountBody,
  DeleteAccountParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/accounts", async (req, res): Promise<void> => {
  const accounts = await db
    .select({
      id: accountsTable.id,
      name: accountsTable.name,
      instagramAccountId: accountsTable.instagramAccountId,
      createdAt: accountsTable.createdAt,
      updatedAt: accountsTable.updatedAt,
    })
    .from(accountsTable)
    .orderBy(accountsTable.createdAt);

  res.json(accounts);
});

router.post("/accounts", async (req, res): Promise<void> => {
  const parsed = CreateAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const existing = await db
    .select()
    .from(accountsTable)
    .where(eq(accountsTable.instagramAccountId, parsed.data.instagramAccountId))
    .limit(1);

  if (existing.length > 0) {
    res.status(400).json({ error: "An account with this Instagram ID already exists" });
    return;
  }

  const [account] = await db
    .insert(accountsTable)
    .values(parsed.data)
    .returning({
      id: accountsTable.id,
      name: accountsTable.name,
      instagramAccountId: accountsTable.instagramAccountId,
      createdAt: accountsTable.createdAt,
      updatedAt: accountsTable.updatedAt,
    });

  res.status(201).json(account);
});

router.get("/accounts/:id", async (req, res): Promise<void> => {
  const params = GetAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [account] = await db
    .select({
      id: accountsTable.id,
      name: accountsTable.name,
      instagramAccountId: accountsTable.instagramAccountId,
      createdAt: accountsTable.createdAt,
      updatedAt: accountsTable.updatedAt,
    })
    .from(accountsTable)
    .where(eq(accountsTable.id, params.data.id));

  if (!account) {
    res.status(404).json({ error: "Account not found" });
    return;
  }

  res.json(account);
});

router.patch("/accounts/:id", async (req, res): Promise<void> => {
  const params = UpdateAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateAccountBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (Object.keys(parsed.data).length === 0) {
    res.status(400).json({ error: "No fields to update" });
    return;
  }

  const [updated] = await db
    .update(accountsTable)
    .set(parsed.data)
    .where(eq(accountsTable.id, params.data.id))
    .returning({
      id: accountsTable.id,
      name: accountsTable.name,
      instagramAccountId: accountsTable.instagramAccountId,
      createdAt: accountsTable.createdAt,
      updatedAt: accountsTable.updatedAt,
    });

  if (!updated) {
    res.status(404).json({ error: "Account not found" });
    return;
  }

  res.json(updated);
});

router.delete("/accounts/:id", async (req, res): Promise<void> => {
  const params = DeleteAccountParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(accountsTable)
    .where(eq(accountsTable.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Account not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
