# PostAll

Instagram posting tool backend — manage multiple Instagram accounts, create posts with media, and publish directly to Instagram via the Graph API.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/accounts.ts` — Instagram accounts table
- `lib/db/src/schema/posts.ts` — Posts table (draft/scheduled/published/failed)
- `lib/db/src/schema/post-media.ts` — Media items per post (supports carousels)
- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth)
- `artifacts/api-server/src/routes/accounts.ts` — Accounts CRUD routes
- `artifacts/api-server/src/routes/posts/index.ts` — Posts CRUD + publish routes
- `artifacts/api-server/src/lib/instagram.ts` — Instagram Graph API publisher

## Architecture decisions

- Access tokens stored in the `accounts` table — never returned in list responses (only selected columns are returned)
- Posts support single images, single videos (Reels), and carousels (up to 10 items)
- Video containers poll the Graph API until `status_code === FINISHED` before publishing
- On publish failure the post status is set to `failed` with `error_message` preserved in DB
- Media items are replaced atomically on PATCH (delete all + re-insert)

## Product

- **Accounts**: Add Instagram Business/Creator accounts by providing a name, Instagram Account ID, and long-lived access token
- **Posts**: Create posts with a caption and one or more media items (images or videos), set status to `draft` or `scheduled`
- **Publish**: `POST /api/posts/:id/publish` triggers immediate publishing to Instagram — supports single image, Reels, and carousels

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/accounts | List all accounts |
| POST | /api/accounts | Add an Instagram account |
| GET | /api/accounts/:id | Get an account |
| DELETE | /api/accounts/:id | Remove an account |
| GET | /api/posts | List posts (filter by accountId, status) |
| POST | /api/posts | Create a post |
| GET | /api/posts/:id | Get a post with media |
| PATCH | /api/posts/:id | Update post caption/status/media |
| DELETE | /api/posts/:id | Delete a post |
| POST | /api/posts/:id/publish | Publish to Instagram now |

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Instagram Graph API requires the Instagram account to be a Business or Creator account linked to a Facebook Page
- Access tokens must be long-lived (60 days); use the Token Debugger to check expiry
- Video posts use the REELS media type on the Graph API
- Always run codegen after editing `openapi.yaml`

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
